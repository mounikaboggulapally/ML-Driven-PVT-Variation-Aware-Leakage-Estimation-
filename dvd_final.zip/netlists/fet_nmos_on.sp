* NMOS ON: single-transistor characterisation netlist (45nm HP)
* Values = sample 1 of the final nmos_on dataset; the generator fills these for every sample.
.options gmin=1e-18 abstol=1e-18 reltol=1e-6 vntol=1e-9
.include "45nm_HP.pm"
.temp 54.400772
VDD vd 0 dc 0.6346620531
VG vg 0 dc 0.9021278924
VS vs 0 dc 0.1310668271
VB vb 0 dc 0
Mn1 vd vg vs vb nmos L=45n W=1.58443e-07
.control
altermod nmos vtho=0.4698985905
altermod nmos toxe=1.348334785e-09
altermod nmos ndep=2.920228258e+18
altermod nmos u0=0.05033208663
altermod nmos xj=1.429761431e-08
op
print i(VDD) i(VG) i(VS) i(VB)
quit
.endc
.end
