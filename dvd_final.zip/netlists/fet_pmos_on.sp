* PMOS ON: single-transistor characterisation netlist (45nm HP)
* Values = sample 1 of the final pmos_on dataset; the generator fills these for every sample.
.options gmin=1e-18 abstol=1e-18 reltol=1e-6 vntol=1e-9
.include "45nm_HP.pm"
.temp -4.885675
VDD vd 0 dc 0.5951246701
VG vg 0 dc 0
VS vs 0 dc 0.7746899057
VB vb 0 dc 0.8254168501
Mp1 vd vg vs vb pmos L=45n W=8.24977e-08
.control
altermod pmos vtho=-0.4893734491
altermod pmos toxe=1.394357482e-09
altermod pmos ndep=2.211148427e+18
altermod pmos u0=0.01956553817
altermod pmos xj=1.352940621e-08
op
print i(VDD) i(VG) i(VS) i(VB)
quit
.endc
.end
