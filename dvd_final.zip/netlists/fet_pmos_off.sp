* PMOS OFF: single-transistor characterisation netlist (45nm HP)
* Values = sample 1 of the final pmos_off dataset; the generator fills these for every sample.
.options gmin=1e-18 abstol=1e-18 reltol=1e-6 vntol=1e-9
.include "45nm_HP.pm"
.temp 100.740913
VDD vd 0 dc 0.6411782342
VG vg 0 dc 0.979750099
VS vs 0 dc 0.06663978557
VB vb 0 dc 0.979750099
Mp1 vd vg vs vb pmos L=45n W=1.90833e-07
.control
altermod pmos vtho=-0.5147212506
altermod pmos toxe=1.210218721e-09
altermod pmos ndep=2.590002298e+18
altermod pmos u0=0.02176843835
altermod pmos xj=1.406474397e-08
op
print i(VDD) i(VG) i(VS) i(VB)
quit
.endc
.end
