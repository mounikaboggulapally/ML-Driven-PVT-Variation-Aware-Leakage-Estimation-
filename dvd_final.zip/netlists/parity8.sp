* 8-bit parity checker (Part C), corner 1, input vector 10110010
* The script steps through all 256 vectors with alter V0..V7 inside one .control block.
.options gmin=1e-18 abstol=1e-18 reltol=1e-6 vntol=1e-9
.include "45nm_HP.pm"
.temp 116.867861
VDD vdd 0 dc 0.8774172214
V0 i0 0 dc 0.8774172214
V1 i1 0 dc 0
V2 i2 0 dc 0.8774172214
V3 i3 0 dc 0.8774172214
V4 i4 0 dc 0
V5 i5 0 dc 0
V6 i6 0 dc 0.8774172214
V7 i7 0 dc 0

* Subcircuits
.subckt NAND2 out in_a in_b vdd
Mp1 out in_a vdd vdd pmos L=45n W=90n
Mp2 out in_b vdd vdd pmos L=45n W=90n
Mn1 out in_a n1 0 nmos L=45n W=45n
Mn2 n1 in_b 0 0 nmos L=45n W=45n
.ends NAND2

.subckt OR2 out in_a in_b vdd
Mp1 p1 in_a vdd vdd pmos L=45n W=90n
Mp2 int_nor in_b p1 vdd pmos L=45n W=90n
Mn1 int_nor in_a 0 0 nmos L=45n W=45n
Mn2 int_nor in_b 0 0 nmos L=45n W=45n
Mp_inv out int_nor vdd vdd pmos L=45n W=90n
Mn_inv out int_nor 0 0 nmos L=45n W=45n
.ends OR2

.subckt AND2 out in_a in_b vdd
Mn1 int_nand in_a n1 0 nmos L=45n W=45n
Mn2 n1 in_b 0 0 nmos L=45n W=45n
Mp1 int_nand in_a vdd vdd pmos L=45n W=90n
Mp2 int_nand in_b vdd vdd pmos L=45n W=90n
Mp_inv out int_nand vdd vdd pmos L=45n W=90n
Mn_inv out int_nand 0 0 nmos L=45n W=45n
.ends AND2

.subckt XOR2 out in_a in_b vdd
Xor w_or in_a in_b vdd OR2
Xnand w_nand in_a in_b vdd NAND2
Xand out w_or w_nand vdd AND2
.ends XOR2

* 8-Bit Tree
* Level 1
Xx1 w11 i0 i1 vdd XOR2
Xx2 w12 i2 i3 vdd XOR2
Xx3 w13 i4 i5 vdd XOR2
Xx4 w14 i6 i7 vdd XOR2
* Level 2
Xx5 w21 w11 w12 vdd XOR2
Xx6 w22 w13 w14 vdd XOR2
* Level 3
Xx7 out w21 w22 vdd XOR2

.control
altermod nmos vtho=0.4906877838
altermod nmos toxe=1.274664621e-09
altermod nmos ndep=3.017100079e+18
altermod nmos u0=0.05028474082
altermod nmos xj=1.276263411e-08
altermod pmos vtho=-0.5275809739
altermod pmos toxe=1.326289903e-09
altermod pmos ndep=2.541539418e+18
altermod pmos u0=0.01808233798
altermod pmos xj=1.531574759e-08
op
print i(VDD) v(out)
quit
.endc
.end
