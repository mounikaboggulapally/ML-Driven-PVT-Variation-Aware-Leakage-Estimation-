* NMOS OFF: single-transistor characterisation netlist (45nm HP)
* Values = sample 1 of the final nmos_off dataset; the generator fills these for every sample.
.options gmin=1e-18 abstol=1e-18 reltol=1e-6 vntol=1e-9
.include "45nm_HP.pm"
.temp 49.868060
VDD vd 0 dc 0.01638151278
VG vg 0 dc 0
VS vs 0 dc 0.6508100304
VB vb 0 dc 0
Mn1 vd vg vs vb nmos L=45n W=8.86729e-08
.control
altermod nmos vtho=0.4802734883
altermod nmos toxe=1.151254689e-09
altermod nmos ndep=3.128698609e+18
altermod nmos u0=0.05084171259
altermod nmos xj=1.342212089e-08
op
print i(VDD) i(VG) i(VS) i(VB)
quit
.endc
.end
