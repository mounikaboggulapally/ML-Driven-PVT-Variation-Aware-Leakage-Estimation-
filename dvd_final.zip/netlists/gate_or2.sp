* OR2 gate netlist (Part B), corner 1, inputs AB=10
* Wn = 45 nm, Wp = 90 nm, L = 45 nm. The script runs every input combination at all 200 corners.
.options gmin=1e-18 abstol=1e-18 reltol=1e-6 vntol=1e-9
.include "45nm_HP.pm"
.temp 116.867861
VDD vdd 0 dc 0.8774172214
VA in_a 0 dc 0.8774172214
VB in_b 0 dc 0
Mp1 p1 in_a vdd vdd pmos L=45n W=90n
Mp2 int_nor in_b p1 vdd pmos L=45n W=90n
Mn1 int_nor in_a 0 0 nmos L=45n W=45n
Mn2 int_nor in_b 0 0 nmos L=45n W=45n
Mp_inv out int_nor vdd vdd pmos L=45n W=90n
Mn_inv out int_nor 0 0 nmos L=45n W=45n
.control
altermod nmos vtho=0.4906877838
altermod nmos toxe=1.274664621e-09
altermod nmos ndep=3.017100079e+18
altermod nmos u0=0.05028474082
altermod nmos xj=1.276263411e-08
altermod pmos vtho=-0.5275809739
altermod pmos toxe=1.326289903e-09
altermod pmos ndep=2.541539418e+18
altermod pmos u0=0.01808233798
altermod pmos xj=1.531574759e-08
op
print i(VDD) v(out) v(p1) v(int_nor)
quit
.endc
.end
